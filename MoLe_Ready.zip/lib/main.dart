
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MoLeApp());
}

class MoLeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MoLe',
      theme: ThemeData(
        fontFamily: 'Cairo',
        primarySwatch: Colors.deepPurple,
      ),
      home: Scaffold(
        appBar: AppBar(title: Text('MoLe Home')),
        body: Center(child: Text('مرحباً بك في MoLe')),
      ),
    );
  }
}
